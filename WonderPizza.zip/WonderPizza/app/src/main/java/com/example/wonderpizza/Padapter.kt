package com.example.wonderpizza

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class Padapter() : RecyclerView.Adapter<Pholder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Pholder {
       return
    }

    override fun onBindViewHolder(holder: Pholder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
       return
    }
}