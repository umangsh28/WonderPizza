package com.example.wonderpizza

import android.view.View
import androidx.recyclerview.widget.RecyclerView

class Pholder(var itemView: View) :RecyclerView.ViewHolder(itemView) {





}